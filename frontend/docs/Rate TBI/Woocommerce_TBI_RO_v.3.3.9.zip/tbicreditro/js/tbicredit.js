	function tbiroChangeContainer(){
		var tbiro_label_container = document.getElementsByClassName("tbiro-label-container")[0];
		if (tbiro_label_container.style.visibility == 'visible'){
			tbiro_label_container.style.visibility = 'hidden';
			tbiro_label_container.style.opacity = 0;
			tbiro_label_container.style.transition = 'visibility 0s, opacity 0.5s ease';				
		}else{
			tbiro_label_container.style.visibility = 'visible';
			tbiro_label_container.style.opacity = 1;			
		}
	}