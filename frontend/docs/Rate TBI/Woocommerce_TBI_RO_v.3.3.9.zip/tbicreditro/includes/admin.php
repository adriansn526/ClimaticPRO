<?php
/** add admin menu */
function tbiro_admin_actions() {
    add_options_page(__('tbi bank - Module settings', 'tbicreditro'), __('tbi bank settings', 'tbicreditro'), 'manage_options', "tbiro-options", "tbiro_admin_options");
}