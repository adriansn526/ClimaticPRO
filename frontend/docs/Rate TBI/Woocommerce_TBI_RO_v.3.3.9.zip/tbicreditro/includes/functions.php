<?php
	/** do output buffer */
	function tbiro_do_output_buffer() {
		ob_start();
	}
	
	/** load admin menu */
	function tbiro_admin_options() {
		include('tbiro_import_admin.php');
	}
	
	/** add origins */
	function tbiro_add_allowed_origins( $origins ) {
		$origins[] = TBIRO_LIVEURL;
		return $origins;
	}
	
	/** add text domain */
	function tbiro_load_textdomain() {
		$locale = apply_filters( 'plugin_locale', determine_locale(), 'tbicreditro' );
		$mofile = 'tbicreditro' . '-' . $locale . '.mo';
		load_textdomain( 'tbicreditro', TBIRO_PLUGIN_DIR . '/languages/' . $mofile );
	}
	
	/** add order column tbiro status */
	function tbiro_add_order_column_status( $columns ) {
		$tbiro_status_columns = ( is_array( $columns ) ) ? $columns : array();
		unset( $tbiro_status_columns[ 'order_actions' ] );
		$tbiro_status_columns['tbiro_status_columnt'] = 'tbi bank status';
		$tbiro_status_columns[ 'order_actions' ] = $columns[ 'order_actions' ];
		return $tbiro_status_columns;
	}
	
	/** add order column tbiro status values */
	function tbiro_add_order_column_status_values( $column ) {
		global $post;
		$data = get_post_meta( $post->ID );
		if ( $column == 'tbiro_status_columnt' ) {
			$tbiro_status = '';
			if (file_exists(TBIRO_PLUGIN_DIR . '/keys/tbiroorders.json')){
				$tbiro_orderdata = file_get_contents(TBIRO_PLUGIN_DIR . '/keys/tbiroorders.json');
				$tbiro_orderdata_all = json_decode($tbiro_orderdata, true);
				foreach ($tbiro_orderdata_all as $key => $value){
					if ($tbiro_orderdata_all[$key]['order_id'] == $post->ID){
						$tbiro_status = $tbiro_orderdata_all[$key]['order_status'];
					}
				}
			}
			echo ( $tbiro_status );
		}
	}
	
	function tbiro_PMT($rate, $nper, $pv, $fv=0, $type = 0) {
		return (-$fv - $pv * pow(1 + $rate, $nper)) / (1 + $rate * $type) / ((pow(1 + $rate, $nper) - 1) / $rate);
	}
	
	/** payment gateway **/
	function tbiro_init_tbiro_gateway_class() {
		class WC_Gateway_Tbiro_Gateway extends WC_Payment_Gateway {
			public $domain;
			
			public function __construct() {
				$this->domain = 'tbicreditro';
				$this->id = 'tbiro';
				$this->icon = apply_filters('woocommerce_custom_gateway_icon', '');
				$this->has_fields = false;
				$this->method_title = __( 'tbi bank', $this->domain );
				$this->method_description = __( 'You pay for the merchandise with tbi bank', $this->domain );
				// Load the settings.
				$this->init_form_fields();
				$this->init_settings();
				// Define user set variables
				$this->title = $this->get_option( 'title' );
				$this->description = $this->get_option( 'description' );
				$this->instructions = $this->get_option( 'instructions', $this->description );
				$this->order_status = $this->get_option( 'order_status', 'completed' );
				// Actions
				add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
				add_action( 'woocommerce_thankyou_tbiro', array( $this, 'thankyou_tbiro_page' ) );
				// Customer Emails
				add_action( 'woocommerce_email_before_order_table', array( $this, 'email_tbiro_instructions' ), 10, 3 );
			}
			
			public function tbiro_PMT($rate, $nper, $pv, $fv=0, $type = 0) {
				return (-$fv - $pv * pow(1 + $rate, $nper)) / (1 + $rate * $type) / ((pow(1 + $rate, $nper) - 1) / $rate);
			}
	
			public function init_form_fields() {
				$this->form_fields = array(
					'enabled' => array(
						'title'   => __( 'Enable/Disable', $this->domain ),
						'type'    => 'checkbox',
						'label'   => __( 'Enable tbi bank', $this->domain ),
						'default' => 'yes'
					),
					'title' => array(
						'title'       => __( 'Title', $this->domain ),
						'type'        => 'text',
						'description' => __( 'tbi bank: Cumpara acum, plateste mai tarziu', $this->domain ),
						'default'     => __( 'tbi bank: Cumpara acum, plateste mai tarziu', $this->domain ),
						'desc_tip'    => true,					
					),
					'order_status' => array(
						'title'       => __( 'Order Status', $this->domain ),
						'type'        => 'select',
						'class'       => 'wc-enhanced-select',
						'description' => __( 'Choose whether status you wish after checkout.', $this->domain ),
						'default'     => 'wc-pending',
						'desc_tip'    => true,
						'options'     => wc_get_order_statuses()
					),
					'description' => array(
						'title'       => __( 'Description', $this->domain ),
						'type'        => 'text',
						'description' => __( '100% online, fara hartii sau drumuri la banca', $this->domain ),
						'default'     => __('100% online, fara hartii sau drumuri la banca', $this->domain),
						'desc_tip'    => true,
					),
					'instructions' => array(
						'title'       => __( 'Instructions', $this->domain ),
						'type'        => 'text',
						'description' => __('100% online, fara hartii sau drumuri la banca', $this->domain),
						'default'     => __('100% online, fara hartii sau drumuri la banca', $this->domain),
						'desc_tip'    => true,
					),
				);
			}
			
			/**
			* Check if the gateway is available for use.
			*
			* @return bool
			*/
			public function is_available() {
				if ( 'yes' !== $this->enabled ){
					return false;
				}
				
				if ( WC()->cart && 0 < $this->get_order_total() && 0 < $this->max_amount && $this->max_amount < $this->get_order_total() ) {
					return false;
				}
				
				$tbiro_unicid = (string)get_option("tbiro_unicid");
				$tbiro_ch = curl_init();
				curl_setopt($tbiro_ch, CURLOPT_SSL_VERIFYPEER, false);
				curl_setopt($tbiro_ch, CURLOPT_RETURNTRANSFER, true);
				curl_setopt($tbiro_ch, CURLOPT_URL, TBIRO_LIVEURL . '/function/getparameters.php?cid='.$tbiro_unicid);
				$paramstbiro = json_decode(curl_exec($tbiro_ch), true);
				curl_close($tbiro_ch);
				
				if (empty($paramstbiro)){
					return NULL;
				}
		
				$tbiro_minstojnost = floatval($paramstbiro['tbi_minstojnost']);
				$tbiro_maxstojnost = floatval($paramstbiro['tbi_maxstojnost']);
				$tbiro_status_tbi = $paramstbiro['tbi_status'];
				if (
					WC()->cart && 
					(
						$tbiro_status_tbi == "No" || 
						$this->get_order_total() < $tbiro_minstojnost || 
						$this->get_order_total() > $tbiro_maxstojnost
					)
				){
					return false;
				}
				
				$is_available = false;
				if (WC()->cart){
					$items = WC()->cart->get_cart();
					foreach($items as $item) {
						$_product = wc_get_product( $item['product_id']); 
						if (($_product->get_stock_quantity() === NULL) || ($_product->get_stock_quantity() !== 0)){
							$is_available = true;
						}else{
							return false;
							break;
						}
					} 
				}
				
				return $is_available;
			}
			
			public function thankyou_tbiro_page() {
				if ( $this->instructions )
                echo wpautop( wptexturize( $this->instructions ) );
			}
			
			public function email_tbiro_instructions( $order, $sent_to_admin, $plain_text = false ) {
				if ( $this->instructions && ! $sent_to_admin && 'tbiro' === $order->payment_method && $order->has_status( 'on-hold' ) ) {
					echo wpautop( wptexturize( $this->instructions ) ) . PHP_EOL;
				}
			}
			
			public function payment_fields(){
				if ( $description = $this->get_description() ) {
					echo wpautop( wptexturize( $description ) );
				}
				$tbiro_unicid = (string)get_option("tbiro_unicid");
				$tbiro_ch = curl_init();
				curl_setopt($tbiro_ch, CURLOPT_SSL_VERIFYPEER, false);
				curl_setopt($tbiro_ch, CURLOPT_RETURNTRANSFER, true);
				curl_setopt($tbiro_ch, CURLOPT_URL, TBIRO_LIVEURL . '/function/getparameters.php?cid='.$tbiro_unicid);
				$paramstbiro = json_decode(curl_exec($tbiro_ch), true);
				curl_close($tbiro_ch);
				
				if (empty($paramstbiro)){
					return NULL;
				}
				
				$tbiro__minprice = $paramstbiro['tbi_minstojnost'];
				global $woocommerce;
				$tbiro__price = $woocommerce->cart->total;
				if ($tbiro__price >= $tbiro__minprice){
					$tbiro_is_visible = true;
				}else{
					$tbiro_is_visible = false;
				}
				$tbiro_tbi_custom_button_status = $paramstbiro['tbi_custom_button_status'];
				$tbiro_vnoska = $paramstbiro['tbi_vnoska'];
				if ($paramstbiro['tbi_backurl'] != ''){
					if (preg_match("#https?://#", $paramstbiro['tbi_backurl']) === 0) {
						$tbiro_backurl = 'http://'.$paramstbiro['tbi_backurl'];
					}else{
						$tbiro_backurl = $paramstbiro['tbi_backurl'];
					}
				}else{
					$tbiro_backurl = '';
				}
				
				$tbi_divider = floatval($paramstbiro['tbi_divider']);
				$tbi_divider2 = floatval($paramstbiro['tbi_divider2']);
				$tbi_divider2_is = boolval($paramstbiro['tbi_divider2_is']);
				$tbi_divider3 = floatval($paramstbiro['tbi_divider3']);
				$tbi_divider3_is = boolval($paramstbiro['tbi_divider3_is']);
				$tbi_divider4 = floatval($paramstbiro['tbi_divider4']);
				$tbi_divider4_is = boolval($paramstbiro['tbi_divider4_is']);
				$tbi_divider5 = floatval($paramstbiro['tbi_divider5']);
				$tbi_divider5_is = boolval($paramstbiro['tbi_divider5_is']);
				
				if ($tbi_divider5_is){
					//divider 5
					if ($tbiro__price < $tbi_divider){
						$tbi_rate = floatval($paramstbiro['tbi_rate']);
						$tbi_commission = floatval($paramstbiro['tbi_commission']);
						$tbi_insurance = floatval($paramstbiro['tbi_insurance']);
						$tbi_months = intval($paramstbiro['tbi_months']);
					}else{
						if ($tbiro__price >= $tbi_divider && $tbiro__price < $tbi_divider2){
							$tbi_rate = floatval($paramstbiro['tbi_rate2']);
							$tbi_commission = floatval($paramstbiro['tbi_commission2']);
							$tbi_insurance = floatval($paramstbiro['tbi_insurance2']);
							$tbi_months = intval($paramstbiro['tbi_months2']);
						}else{
							if ($tbiro__price >= $tbi_divider2 && $tbiro__price < $tbi_divider3){
								$tbi_rate = floatval($paramstbiro['tbi_rate3']);
								$tbi_commission = floatval($paramstbiro['tbi_commission3']);
								$tbi_insurance = floatval($paramstbiro['tbi_insurance3']);
								$tbi_months = intval($paramstbiro['tbi_months3']);
							}else{
								if ($tbiro__price >= $tbi_divider3 && $tbiro__price < $tbi_divider4){
									$tbi_rate = floatval($paramstbiro['tbi_rate4']);
									$tbi_commission = floatval($paramstbiro['tbi_commission4']);
									$tbi_insurance = floatval($paramstbiro['tbi_insurance4']);
									$tbi_months = intval($paramstbiro['tbi_months4']);
								}else{
									if ($tbiro__price >= $tbi_divider4 && $tbiro__price < $tbi_divider5){
										$tbi_rate = floatval($paramstbiro['tbi_rate5']);
										$tbi_commission = floatval($paramstbiro['tbi_commission5']);
										$tbi_insurance = floatval($paramstbiro['tbi_insurance5']);
										$tbi_months = intval($paramstbiro['tbi_months5']);
									}else{
										$tbi_rate = floatval($paramstbiro['tbi_rate6']);
										$tbi_commission = floatval($paramstbiro['tbi_commission6']);
										$tbi_insurance = floatval($paramstbiro['tbi_insurance6']);
										$tbi_months = intval($paramstbiro['tbi_months6']);
									}
								}
							}
						}
					}
				}else{
					if ($tbi_divider4_is){
						//divider 4
						if ($tbiro__price < $tbi_divider){
							$tbi_rate = floatval($paramstbiro['tbi_rate']);
							$tbi_commission = floatval($paramstbiro['tbi_commission']);
							$tbi_insurance = floatval($paramstbiro['tbi_insurance']);
							$tbi_months = intval($paramstbiro['tbi_months']);
						}else{
							if ($tbiro__price >= $tbi_divider && $tbiro__price < $tbi_divider2){
								$tbi_rate = floatval($paramstbiro['tbi_rate2']);
								$tbi_commission = floatval($paramstbiro['tbi_commission2']);
								$tbi_insurance = floatval($paramstbiro['tbi_insurance2']);
								$tbi_months = intval($paramstbiro['tbi_months2']);
							}else{
								if ($tbiro__price >= $tbi_divider2 && $tbiro__price < $tbi_divider3){
									$tbi_rate = floatval($paramstbiro['tbi_rate3']);
									$tbi_commission = floatval($paramstbiro['tbi_commission3']);
									$tbi_insurance = floatval($paramstbiro['tbi_insurance3']);
									$tbi_months = intval($paramstbiro['tbi_months3']);
								}else{
									if ($tbiro__price >= $tbi_divider3 && $tbiro__price < $tbi_divider4){
										$tbi_rate = floatval($paramstbiro['tbi_rate4']);
										$tbi_commission = floatval($paramstbiro['tbi_commission4']);
										$tbi_insurance = floatval($paramstbiro['tbi_insurance4']);
										$tbi_months = intval($paramstbiro['tbi_months4']);
									}else{
										$tbi_rate = floatval($paramstbiro['tbi_rate5']);
										$tbi_commission = floatval($paramstbiro['tbi_commission5']);
										$tbi_insurance = floatval($paramstbiro['tbi_insurance5']);
										$tbi_months = intval($paramstbiro['tbi_months5']);
									}
								}
							}
						}
					}else{
						if ($tbi_divider3_is){
							//divider 3
							if ($tbiro__price < $tbi_divider){
								$tbi_rate = floatval($paramstbiro['tbi_rate']);
								$tbi_commission = floatval($paramstbiro['tbi_commission']);
								$tbi_insurance = floatval($paramstbiro['tbi_insurance']);
								$tbi_months = intval($paramstbiro['tbi_months']);
							}else{
								if ($tbiro__price >= $tbi_divider && $tbiro__price < $tbi_divider2){
									$tbi_rate = floatval($paramstbiro['tbi_rate2']);
									$tbi_commission = floatval($paramstbiro['tbi_commission2']);
									$tbi_insurance = floatval($paramstbiro['tbi_insurance2']);
									$tbi_months = intval($paramstbiro['tbi_months2']);
								}else{
									if ($tbiro__price >= $tbi_divider2 && $tbiro__price < $tbi_divider3){
										$tbi_rate = floatval($paramstbiro['tbi_rate3']);
										$tbi_commission = floatval($paramstbiro['tbi_commission3']);
										$tbi_insurance = floatval($paramstbiro['tbi_insurance3']);
										$tbi_months = intval($paramstbiro['tbi_months3']);
									}else{
										$tbi_rate = floatval($paramstbiro['tbi_rate4']);
										$tbi_commission = floatval($paramstbiro['tbi_commission4']);
										$tbi_insurance = floatval($paramstbiro['tbi_insurance4']);
										$tbi_months = intval($paramstbiro['tbi_months4']);
									}
								}
							}
						}else{
							if ($tbi_divider2_is){
								//divider 2
								if ($tbiro__price < $tbi_divider){
									$tbi_rate = floatval($paramstbiro['tbi_rate']);
									$tbi_commission = floatval($paramstbiro['tbi_commission']);
									$tbi_insurance = floatval($paramstbiro['tbi_insurance']);
									$tbi_months = intval($paramstbiro['tbi_months']);
								}else{
									if ($tbiro__price >= $tbi_divider && $tbiro__price < $tbi_divider2){
										$tbi_rate = floatval($paramstbiro['tbi_rate2']);
										$tbi_commission = floatval($paramstbiro['tbi_commission2']);
										$tbi_insurance = floatval($paramstbiro['tbi_insurance2']);
										$tbi_months = intval($paramstbiro['tbi_months2']);
									}else{
										$tbi_rate = floatval($paramstbiro['tbi_rate3']);
										$tbi_commission = floatval($paramstbiro['tbi_commission3']);
										$tbi_insurance = floatval($paramstbiro['tbi_insurance3']);
										$tbi_months = intval($paramstbiro['tbi_months3']);
									}
								}
							}else{
								//no dividers
								if ($tbiro__price < $tbi_divider){
									$tbi_rate = floatval($paramstbiro['tbi_rate']);
									$tbi_commission = floatval($paramstbiro['tbi_commission']);
									$tbi_insurance = floatval($paramstbiro['tbi_insurance']);
									$tbi_months = intval($paramstbiro['tbi_months']);
								}else{
									$tbi_rate = floatval($paramstbiro['tbi_rate2']);
									$tbi_commission = floatval($paramstbiro['tbi_commission2']);
									$tbi_insurance = floatval($paramstbiro['tbi_insurance2']);
									$tbi_months = intval($paramstbiro['tbi_months2']);
								}
							}
						}
					}
				}
				
				if ($tbi_rate == 0){
					$tbi_rate = 1;
				}
				
				$tbiro_mesecna = $this->tbiro_PMT(($tbi_rate / 100) / 12, $tbi_months,  - ($tbiro__price + $tbi_commission) * (1 + $tbi_insurance * $tbi_months));
				
				$tbiro_tbi_btn_theme = $paramstbiro['tbi_btn_theme'];
				$tbi_btn_color = '#e55a00;';
				if ($paramstbiro['tbi_btn_theme'] == 'tbi'){
					$tbi_btn_color = '#e55a00;';
				}
				if ($paramstbiro['tbi_btn_theme'] == 'tbi2'){
					$tbi_btn_color = '#00368a;';
				}
				if ($paramstbiro['tbi_btn_theme'] == 'tbi3'){
					$tbi_btn_color = '#2b7953;';
				}
				if ($paramstbiro['tbi_btn_theme'] == 'tbi4'){
					$tbi_btn_color = '#848789;';
				}
				if ($tbiro_is_visible) {
					if ($tbiro_tbi_custom_button_status == 'Yes') {
						if ($tbiro_vnoska == 'Yes'){
							echo '<table border="0" cellpadding="0" cellspacing="0">';
							echo '<tr>';
							echo '<td style="float:left;padding-right:5px;padding-bottom:5px;">';
							if ($tbiro_backurl == ''){
								echo "<img id=\"btn_tbiro\" style=\"min-width:155px;min-height:55px;\" src=\"".TBIRO_LIVEURL."/calculators/assets/img/custom_buttons/" . $tbiro_unicid . ".png\" title=\"Credit module tbi bank " . TBIRO_MOD_VERSION . "\" alt=\"Credit module tbi bank " . TBIRO_MOD_VERSION . "\" onmouseover=\"this.src='".TBIRO_LIVEURL."/calculators/assets/img/custom_buttons/" . $tbiro_unicid . "_hover.png'\" onmouseout=\"this.src='".TBIRO_LIVEURL."/calculators/assets/img/custom_buttons/" . $tbiro_unicid . ".png'\">";
							}else{
								echo "<a href=\"" . $tbiro_backurl . "\" target=\"_blank\" title=\"Go to tbi bank page\"><img id=\"btn_tbiro\" style=\"cursor:pointer;min-width:155px;min-height:55px;\" src=\"".TBIRO_LIVEURL."/calculators/assets/img/custom_buttons/" . $tbiro_unicid . ".png\" title=\"Credit module tbi bank " . TBIRO_MOD_VERSION . "\" alt=\"Credit module tbi bank " . TBIRO_MOD_VERSION . "\" onmouseover=\"this.src='".TBIRO_LIVEURL."/calculators/assets/img/custom_buttons/" . $tbiro_unicid . "_hover.png'\" onmouseout=\"this.src='".TBIRO_LIVEURL."/calculators/assets/img/custom_buttons/" . $tbiro_unicid . ".png'\"></a>";
							}
							echo '</td>';
							echo '</tr>';
							echo '<tr>';
							echo '<td style="vertical-align:bottom;">';
							echo '<p style="color:' . $tbi_btn_color . 'font-size:16pt;font-weight:bold;">' . number_format($tbiro_mesecna, 2, '.', '') . ' ' . __('EUR', $this->domain) . ' x ' . $tbi_months . ' ' . __('months', $this->domain) . '</p>';
							echo '</td>';
							echo '</tr>';
							echo '</table>';
						}else{
							echo '<table border="0" cellpadding="0" cellspacing="0">';
							echo '<tr>';
							echo '<td style="float:left;padding-right:5px;padding-bottom:5px;">';
							if ($tbiro_backurl == ''){
								echo "<img id=\"btn_tbiro\" style=\"min-width:155px;min-height:55px;\" src=\"".TBIRO_LIVEURL."/calculators/assets/img/custom_buttons/" . $tbiro_unicid . ".png\" title=\"Credit module tbi bank " . TBIRO_MOD_VERSION . "\" alt=\"Credit module tbi bank " . TBIRO_MOD_VERSION . "\" onmouseover=\"this.src='".TBIRO_LIVEURL."/calculators/assets/img/custom_buttons/" . $tbiro_unicid . "_hover.png'\" onmouseout=\"this.src='".TBIRO_LIVEURL."/calculators/assets/img/custom_buttons/" . $tbiro_unicid . ".png'\">";
							}else{
								echo "<a href=\"" . $tbiro_backurl . "\" target=\"_blank\" title=\"Go to tbi bank page\"><img id=\"btn_tbiro\" style=\"cursor:pointer;min-width:155px;min-height:55px;\" src=\"".TBIRO_LIVEURL."/calculators/assets/img/custom_buttons/" . $tbiro_unicid . ".png\" title=\"Credit module tbi bank " . TBIRO_MOD_VERSION . "\" alt=\"Credit module tbi bank " . TBIRO_MOD_VERSION . "\" onmouseover=\"this.src='".TBIRO_LIVEURL."/calculators/assets/img/custom_buttons/" . $tbiro_unicid . "_hover.png'\" onmouseout=\"this.src='".TBIRO_LIVEURL."/calculators/assets/img/custom_buttons/" . $tbiro_unicid . ".png'\"></a>";
							}
							echo '</td>';
							echo '</tr>';
							echo '</table>';
						}
					}else{
						if ($tbiro_vnoska == 'Yes'){
							echo '<table border="0" cellpadding="0" cellspacing="0">';
							echo '<tr>';
							echo '<td style="float:left;padding-right:5px;padding-bottom:5px;">';
							if ($tbiro_backurl == ''){
								echo "<img id=\"btn_tbiro\" style=\"min-width:155px;min-height:55px;\" src=\"".TBIRO_LIVEURL."/calculators/assets/img/buttons/" . $tbiro_tbi_btn_theme . ".png\" title=\"Credit module tbi bank " . TBIRO_MOD_VERSION . "\" alt=\"Credit module tbi bank " . TBIRO_MOD_VERSION . "\" onmouseover=\"this.src='".TBIRO_LIVEURL."/calculators/assets/img/buttons/" . $tbiro_tbi_btn_theme . "-hover.png'\" onmouseout=\"this.src='".TBIRO_LIVEURL."/calculators/assets/img/buttons/" . $tbiro_tbi_btn_theme . ".png'\">";
							}else{
								echo "<a href=\"" . $tbiro_backurl . "\" target=\"_blank\" title=\"Go to tbi bank page\"><img id=\"btn_tbiro\" style=\"cursor:pointer;min-width:155px;min-height:55px;\" src=\"".TBIRO_LIVEURL."/calculators/assets/img/buttons/" . $tbiro_tbi_btn_theme . ".png\" title=\"Credit module tbi bank " . TBIRO_MOD_VERSION . "\" alt=\"Credit module tbi bank " . TBIRO_MOD_VERSION . "\" onmouseover=\"this.src='".TBIRO_LIVEURL."/calculators/assets/img/buttons/" . $tbiro_tbi_btn_theme . "-hover.png'\" onmouseout=\"this.src='".TBIRO_LIVEURL."/calculators/assets/img/buttons/" . $tbiro_tbi_btn_theme . ".png'\"></a>";
							}
							echo '</td>';
							echo '</tr>';
							echo '<tr>';
							echo '<td style="vertical-align:bottom;">';
							echo '<p style="color:' . $tbi_btn_color . 'font-size:16pt;font-weight:bold;">' . number_format($tbiro_mesecna, 2, '.', '') . ' ' . __('EUR', $this->domain) . ' x ' . $tbi_months . ' ' . __('months', $this->domain) . '</p>';
							echo '</td>';
							echo '</tr>';
							echo '</table>';
						}else{
							echo '<table border="0" cellpadding="0" cellspacing="0">';
							echo '<tr>';
							echo '<td style="float:left;padding-right:5px;padding-bottom:5px;">';
							if ($tbiro_backurl == ''){
								echo "<img id=\"btn_tbiro\" style=\"min-width:155px;min-height:55px;\" src=\"".TBIRO_LIVEURL."/calculators/assets/img/buttons/" . $tbiro_tbi_btn_theme . ".png\" title=\"Credit module tbi bank " . TBIRO_MOD_VERSION . "\" alt=\"Credit module tbi bank " . TBIRO_MOD_VERSION . "\" onmouseover=\"this.src='".TBIRO_LIVEURL."/calculators/assets/img/buttons/" . $tbiro_tbi_btn_theme . "-hover.png'\" onmouseout=\"this.src='".TBIRO_LIVEURL."/calculators/assets/img/buttons/" . $tbiro_tbi_btn_theme . ".png'\">";
							}else{
								echo "<a href=\"" . $tbiro_backurl . "\" target=\"_blank\" title=\"Go to tbi bank page\"><img id=\"btn_tbiro\" style=\"cursor:pointer;min-width:155px;min-height:55px;\" src=\"".TBIRO_LIVEURL."/calculators/assets/img/buttons/" . $tbiro_tbi_btn_theme . ".png\" title=\"Credit module tbi bank " . TBIRO_MOD_VERSION . "\" alt=\"Credit module tbi bank " . TBIRO_MOD_VERSION . "\" onmouseover=\"this.src='".TBIRO_LIVEURL."/calculators/assets/img/buttons/" . $tbiro_tbi_btn_theme . "-hover.png'\" onmouseout=\"this.src='".TBIRO_LIVEURL."/calculators/assets/img/buttons/" . $tbiro_tbi_btn_theme . ".png'\"></a>";
							}
							echo '</td>';
							echo '</tr>';
							echo '</table>';
						}
					}
				}
			}
			
			public function process_payment( $order_id ) {
				$order = wc_get_order( $order_id );
				$status = 'wc-' === substr( $this->order_status, 0, 3 ) ? substr( $this->order_status, 3 ) : $this->order_status;
				// Set order status
				$order->update_status( $status, __( 'tbi bank. ', $this->domain ) );
				
				$tbiro_unicid = (string)get_option("tbiro_unicid");
				$tbiro_store_id = (string)get_option('credittbiro_store_id');
				$tbiro_username = (string)get_option('credittbiro_username');
				$tbiro_password = (string)get_option('credittbiro_password');
				$tbiro_ch = curl_init();
				curl_setopt($tbiro_ch, CURLOPT_SSL_VERIFYPEER, false);
				curl_setopt($tbiro_ch, CURLOPT_RETURNTRANSFER, true);
				curl_setopt($tbiro_ch, CURLOPT_URL, TBIRO_LIVEURL . '/function/getparameters.php?cid='.$tbiro_unicid);
				$paramstbiro = json_decode(curl_exec($tbiro_ch), true);
				curl_close($tbiro_ch);
				
				if (empty($paramstbiro)){
					return NULL;
				}
				
				global $woocommerce;
				$tbiro__price = 0;
				$tbiro__minprice = $paramstbiro['tbi_minstojnost'];
				$tbiro__price = $woocommerce->cart->total;
				
				$tbiro_products = '';
				$tbiro_products_q = '';
				$tbiro_products_n = '';
				$ident = 0;
				foreach($woocommerce->cart->get_cart() as $cart_item){
					if(!empty($cart_item)){
						$tbiro_items[$ident]['name'] = $cart_item['data']->get_title();
						$tbiro_quantity = $cart_item['quantity'];
						$tbiro_items[$ident]['qty'] = "$tbiro_quantity";
						$tbiro_price = (float)$cart_item['line_total'] / (float)$cart_item['quantity'];
						$tbiro_items[$ident]['price'] = "$tbiro_price";
						$terms = get_the_terms( $cart_item['product_id'], 'product_cat' );
						foreach ($terms as $term){
							$tbiro_category = $term->term_id;
						}
						$tbiro_items[$ident]['category'] = "$tbiro_category";
						$tbiro_product_id = $cart_item['product_id'];
						$tbiro_items[$ident]['sku'] = "$tbiro_product_id";
						$tbiro_image = wp_get_attachment_image_src( get_post_thumbnail_id( $cart_item['product_id'] ), 'single-post-thumbnail' );
						$tbiro_imagePath = isset($tbiro_image[0]) ? $tbiro_image[0] : '';
						$tbiro_items[$ident]['ImageLink'] = "$tbiro_imagePath";
						$ident++;
					}
				}
				
				$tbiro_btn_theme = $paramstbiro['tbi_btn_theme'];
				$tbiro_custom_button_status = $paramstbiro['tbi_custom_button_status'];
				
				if ($tbiro__price == 0){
					$tbiro_is_empty = true;
					}else{
					$tbiro_is_empty = false;
				}
				
				if ($paramstbiro['tbi_status'] == 'Yes'){
					$tbiro_is_active = true;
					}else{
					$tbiro_is_active = false;
				}
				
				if ($tbiro__price >= $tbiro__minprice){
					$tbiro_is_visible = true;
				}else{
					$tbiro_is_visible = false;
				}
				
				$tbiro_zaiavka1tbi_text = $paramstbiro['tbi_zaglavie'];
				$tbiro_zaiavka2tbi_text = $paramstbiro['tbi_opisanie'];
				$tbiro_zaiavka3tbi_text = $paramstbiro['tbi_product'];
				
				global $current_user;
				get_currentuserinfo();
				
				$tbiro_url = TBIRO_LIVEURL . "/function/status.php";
				$tbiro_fname = isset($current_user->user_firstname) ? $current_user->user_firstname : tbiro_wordpress_get_params( 'billing_first_name', '' );
				$tbiro_lname = isset($current_user->user_firstname) ? $current_user->user_lastname : tbiro_wordpress_get_params( 'billing_last_name', '' );
				$tbiro_cnp = '';
				$tbiro_email = isset($current_user->user_email) ? $current_user->user_email : tbiro_wordpress_get_params( 'billing_email', '' );
				$tbiro_person_type = '';
				$tbiro_net_income = '';
				$tbiro_instalments = '';
				$tbiro_quantity = tbiro_wordpress_get_params( 'tbiro_newq', 1 );
				$tbiro_product_category = '';
				$tbiro_customer = new WC_Customer( $current_user->ID );
				$tbiro_phone = ($tbiro_customer->get_billing_phone() !== '') ? $tbiro_customer->get_billing_phone() : tbiro_wordpress_get_params( 'billing_phone', '' );
				$tbiro_billing_address = ($tbiro_customer->get_billing_address() !== '') ? $tbiro_customer->get_billing_address() : tbiro_wordpress_get_params( 'billing_address_1', '' ) . ' ' . tbiro_wordpress_get_params( 'billing_address_2', '' );
				$tbiro_billing_city = ($tbiro_customer->get_billing_city() !== '') ? $tbiro_customer->get_billing_city() : tbiro_wordpress_get_params( 'billing_city', '' );
				$tbiro_billing_county = ($tbiro_customer->get_billing_state() !== '') ? $tbiro_customer->get_billing_state() : tbiro_wordpress_get_params( 'billing_state', '' );
				$tbiro_shipping_address = ($tbiro_customer->get_shipping_address() !== '') ? $tbiro_customer->get_shipping_address() : tbiro_wordpress_get_params( 'billing_address_1', '' ) . ' ' . tbiro_wordpress_get_params( 'billing_address_2', '' );
				$tbiro_shipping_city = ($tbiro_customer->get_shipping_city() !== '') ? $tbiro_customer->get_shipping_city() : tbiro_wordpress_get_params( 'billing_city', '' );
				$tbiro_shipping_county = ($tbiro_customer->get_shipping_state() !== '') ? $tbiro_customer->get_shipping_state() : tbiro_wordpress_get_params( 'billing_state', '' );
				
				// create order in cp
				$tbiro_add_ch = curl_init();
				curl_setopt($tbiro_add_ch, CURLOPT_SSL_VERIFYPEER, false);
				curl_setopt($tbiro_add_ch, CURLOPT_RETURNTRANSFER, true);
				curl_setopt($tbiro_add_ch, CURLOPT_URL, TBIRO_LIVEURL . '/function/addorders.php?cid='.$tbiro_unicid);
				curl_setopt($tbiro_add_ch, CURLOPT_POST, 1);
				$tbiro_post = array(
					'store_id'      => $tbiro_store_id,
					'order_id'      =>  $order_id,
					'type'      	=>  'TBI',
					'back_ref'      =>  $tbiro_url,
					'order_total'   =>  $tbiro__price,
					'username'	=> $tbiro_username,
					'password'	=> $tbiro_password,
					'customer'      =>  array(
						'fname'         => $tbiro_fname,
						'lname'         => $tbiro_lname,
						'cnp'           => $tbiro_cnp,
						'email'         => $tbiro_email,
						'phone'         => $tbiro_phone,
						'billing_address'      => $tbiro_billing_address,
						'billing_city'          => $tbiro_billing_city,
						'billing_county'        => $tbiro_billing_county,
						'shipping_address'      => $tbiro_shipping_address,
						'shipping_city'          => $tbiro_shipping_city,
						'shipping_county'        => $tbiro_shipping_county,
						'person_type'   => $tbiro_person_type,
						'net_income'    => $tbiro_net_income,
						'instalments'	=> $tbiro_instalments
					),
					'items' => $tbiro_items
				);
				
				curl_setopt($tbiro_add_ch, CURLOPT_POSTFIELDS, http_build_query($tbiro_post));
				$paramstbiroadd=json_decode(curl_exec($tbiro_add_ch), true);
				curl_close($tbiro_add_ch);				
				
				// created order in cp
				if (isset($paramstbiroadd['status']) && ($paramstbiroadd['status'] == 'Yes')){
					// save to tbiorders file
					$tbiro_tempcontent = file_get_contents(TBIRO_PLUGIN_DIR . '/keys/tbiroorders.json');
					if ($tbiro_tempcontent != false){
						$tbiro_orders = json_decode($tbiro_tempcontent);
						// test over 1000
						if (is_array($tbiro_orders) && (count($tbiro_orders) >= 1000)){
							array_shift($tbiro_orders);
						}
						$tbiro_order_current = array(
							"order_id" => $order_id,
							"order_status" => "Draft"
						);
						$key = array_search($order_id, array_map(
							function($o) {
								return $o->order_id;
							}, 
							$tbiro_orders));
						if ($key === false){
							array_push($tbiro_orders, $tbiro_order_current);
						}
						$jsondata = json_encode($tbiro_orders);
						file_put_contents(TBIRO_PLUGIN_DIR . '/keys/tbiroorders.json', $jsondata);
					}
					
					// send to softinteligens
					$tbiro_post = array(
						'store_id'      => $tbiro_store_id,
						'order_id'      =>  $paramstbiroadd['newid'],
						'back_ref'      =>  $tbiro_url,
						'order_total'   =>  $tbiro__price,
						'username'		=> $tbiro_username,
						'password'		=> $tbiro_password,
						'avalonorderid'	=> (string)$order_id,
						'customer'      =>  array(
							'fname'         => $tbiro_fname,
							'lname'         => $tbiro_lname,
							'cnp'           => $tbiro_cnp,
							'email'         => $tbiro_email,
							'phone'         => $tbiro_phone,
							'billing_address'      => $tbiro_billing_address,
							'billing_city'          => $tbiro_billing_city,
							'billing_county'        => $tbiro_billing_county,
							'shipping_address'      => $tbiro_shipping_address,
							'shipping_city'          => $tbiro_shipping_city,
							'shipping_county'        => $tbiro_shipping_county,
							'person_type'   => $tbiro_person_type,
							'net_income'    => $tbiro_net_income,
							'instalments'	=> $tbiro_instalments
						),
						'items' => $tbiro_items
					);
					
					$tbiro_plaintext = json_encode($tbiro_post);
					
					if ($paramstbiro['tbi_testenv'] == 1){
						$tbiro_envurl = $paramstbiro['tbi_testurl'];
					}else{
						$tbiro_envurl = $paramstbiro['tbi_liveurl'];
					}
					
					$tbiro_publicKey = openssl_pkey_get_public(file_get_contents(TBIRO_PLUGIN_DIR . '/keys/public.key'));
					$tbiro_a_key = openssl_pkey_get_details($tbiro_publicKey);
					$tbiro_chunkSize = ceil($tbiro_a_key['bits'] / 8) - 11;
					$tbiro_output = '';
					while ($tbiro_plaintext) {
						$tbiro_chunk = substr($tbiro_plaintext, 0, $tbiro_chunkSize);
						$tbiro_plaintext = substr($tbiro_plaintext, $tbiro_chunkSize);
						$tbiro_encrypted = '';
						if (!openssl_public_encrypt($tbiro_chunk, $tbiro_encrypted, $tbiro_publicKey)) {
							die('Failed to encrypt data');
						}
						$tbiro_output .= $tbiro_encrypted;
					}
					if (intval(substr(phpversion(), 0, 1)) < 8){
						openssl_free_key($tbiro_publicKey);
					}
					$tbiro_output64 = base64_encode($tbiro_output);
					
					$tbiro_post_data = array('order_data' => $tbiro_output64, 'providerCode' => 'avast');
					
					$curl_tbiro = curl_init();
					curl_setopt_array($curl_tbiro, array(
						CURLOPT_URL => $tbiro_envurl,
						CURLOPT_RETURNTRANSFER => true,
						CURLOPT_ENCODING => '',
						CURLOPT_MAXREDIRS => 10,
						CURLOPT_TIMEOUT => 0,
						CURLOPT_FOLLOWLOCATION => true,
						CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
						CURLOPT_CUSTOMREQUEST => 'POST',
						CURLOPT_HEADER => true,
						CURLOPT_HTTPHEADER => array(
							"Content-Type: multipart/form-data"
						),
						CURLOPT_POSTFIELDS => $tbiro_post_data,
					));
					$result_curl_tbiro = curl_exec($curl_tbiro);
					$tbiro_header_size = curl_getinfo($curl_tbiro , CURLINFO_HEADER_SIZE);
					$curl_tbiro_error = curl_error($curl_tbiro);
					curl_close($curl_tbiro);
					
					if ($curl_tbiro_error){
						wc_add_notice(__( 'Communication error. You cannot create an order in tbi bank ftos. Please try again later.', 'tbicreditro' ), 'error');
						return NULL;
					}else{
						$tbiro_header_str = substr($result_curl_tbiro , 0 , $tbiro_header_size);
						$tbiro_headers = headersToArray($tbiro_header_str);
						if (array_key_exists('Location', $tbiro_headers)){
							$tbiro_new_location = preg_replace('/\s+/', '', $tbiro_headers['Location']);
							WC()->cart->empty_cart();
							return array(
								'result'    => 'success',
								'redirect'  => esc_url_raw($tbiro_new_location)
							);
						}else{
							wc_add_notice(__( 'You cannot create an order in tbi bank ftos. Please try again later.', 'tbicreditro' ), 'error');
							return NULL;
						}
					}
				}else{
					wc_add_notice(__( 'You cannot create an order in tbi bank cp. Please try again later.', 'tbicreditro' ), 'error');
					return NULL;
				}
			}
		}
	}
	
	/** payment gateway tbi iris **/
	function tbiro_init_tbiiris_gateway_class() {
		class WC_Gateway_Tbiroiris_Gateway extends WC_Payment_Gateway {
			public $domain;
			
			public function __construct() {
				$this->id = 'tbiirisro';
				$this->icon = apply_filters('woocommerce_custom_gateway_icon', '');
				$this->has_fields = false;
				$this->method_title = __( 'Pay width IRIS Pay', 'tbicreditro' );
				$this->method_description = __( 'You pay for the merchandise with IRIS Pay', 'tbicreditro' );
				// Load the settings.
				$this->init_form_fields();
				$this->init_settings();
				// Define user set variables
				$this->title = $this->get_option( 'title' );
				$this->description = $this->get_option( 'description' );
				$this->instructions = $this->get_option( 'instructions', $this->description );
				$this->order_status = $this->get_option( 'order_status', 'completed' );
				// Actions
				add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
				add_action( 'woocommerce_thankyou_tbiirisro', array( $this, 'thankyou_tbiirisro_page' ) );
				// Customer Emails
				add_action( 'woocommerce_email_before_order_table', array( $this, 'email_tbiroiris_instructions' ), 10, 3 );
			}
			
			public function TBIIRIS_PMT($rate, $nper, $pv, $fv=0, $type = 0) {
				return (-$fv - $pv * pow(1 + $rate, $nper)) / (1 + $rate * $type) / ((pow(1 + $rate, $nper) - 1) / $rate);
			}
	
			public function init_form_fields() {
				$this->form_fields = array(
					'enabled' => array(
						'title'   => __( 'Enable/Disable', 'tbicreditro' ),
						'type'    => 'checkbox',
						'label'   => __( 'Enable IRIS Pay', 'tbicreditro' ),
						'default' => 'no'
					),
						'title' => array(
						'title'       => __( 'Title', 'tbicreditro' ),
						'type'        => 'text',
						'description' => __( 'This controls the title which the user sees during checkout.', 'tbicreditro' ),
						'default'     => __( 'IRIS Pay', 'tbicreditro' ),
						'desc_tip'    => true,
					),
						'order_status' => array(
						'title'       => __( 'Order Status', 'tbicreditro' ),
						'type'        => 'select',
						'class'       => 'wc-enhanced-select',
						'description' => __( 'Choose whether status you wish after checkout.', 'tbicreditro' ),
						'default'     => 'wc-pending',
						'desc_tip'    => true,
						'options'     => wc_get_order_statuses()
					),
						'description' => array(
						'title'       => __( 'Description', 'tbicreditro' ),
						'type'        => 'textarea',
						'description' => __( 'Payment method description that the customer will see on your checkout.', 'tbicreditro' ),
						'default'     => __('You pay for the merchandise with IRIS Pay', 'tbicreditro'),
						'desc_tip'    => true,
					),
						'instructions' => array(
						'title'       => __( 'Instructions', 'tbicreditro' ),
						'type'        => 'textarea',
						'description' => __( 'Instructions that will be added to the thank you page and emails.', 'tbicreditro' ),
						'default'     => '',
						'desc_tip'    => true,
					),
				);
			}
			
			/**
			* Check if the gateway is available for use.
			*
			* @return bool
			*/
			public function is_available() {
				if ( 'yes' !== $this->enabled ){
					return false;
				}
				
				if ( WC()->cart && 0 < $this->get_order_total() && 0 < $this->max_amount && $this->max_amount < $this->get_order_total() ) {
					return false;
				}
				
				$tbiro_unicid = (string)get_option("tbiro_unicid");
				$tbiro_ch = curl_init();
				curl_setopt($tbiro_ch, CURLOPT_SSL_VERIFYPEER, false);
				curl_setopt($tbiro_ch, CURLOPT_RETURNTRANSFER, true);
				curl_setopt($tbiro_ch, CURLOPT_URL, TBIRO_LIVEURL . '/function/getparameters.php?cid='.$tbiro_unicid);
				$paramstbiro = json_decode(curl_exec($tbiro_ch), true);
				curl_close($tbiro_ch);
				
				if (empty($paramstbiro)){
					return NULL;
				}
		
				$tbiro_status_iris = $paramstbiro['iris_status'];
				if (WC()->cart && $tbiro_status_iris == "No"){
					return false;
				}
				
				$is_available = false;
				if (WC()->cart){
					$items = WC()->cart->get_cart();
					foreach($items as $item) {
						$_product = wc_get_product( $item['product_id']); 
						if (($_product->get_stock_quantity() === NULL) || ($_product->get_stock_quantity() !== 0)){
							$is_available = true;
						}else{
							return false;
							break;
						}
					} 
				}
				
				return $is_available;
			}
			
			public function thankyou_tbiirisro_page() {
				if ( $this->instructions )
                echo wpautop( wptexturize( $this->instructions ) );
			}
			
			public function email_tbiroiris_instructions( $order, $sent_to_admin, $plain_text = false ) {
				if ( $this->instructions && ! $sent_to_admin && 'tbiirisro' === $order->get_payment_method() && $order->has_status( 'on-hold' ) ) {
					echo wpautop( wptexturize( $this->instructions ) ) . PHP_EOL;
				}
			}
			
			public function payment_fields(){
				if ( $description = $this->get_description() ) {
					echo wpautop( wptexturize( $description ) );
				}
				$tbiro_unicid = (string)get_option("tbiro_unicid");
				$tbiro_ch = curl_init();
				curl_setopt($tbiro_ch, CURLOPT_SSL_VERIFYPEER, false);
				curl_setopt($tbiro_ch, CURLOPT_RETURNTRANSFER, true);
				curl_setopt($tbiro_ch, CURLOPT_URL, TBIRO_LIVEURL . '/function/getparameters.php?cid='.$tbiro_unicid);
				$paramstbiro = json_decode(curl_exec($tbiro_ch), true);
				curl_close($tbiro_ch);
				
				if (empty($paramstbiro)){
					return NULL;
				}
				
				global $woocommerce;
				$tbiro_iris_custom_button_status = $paramstbiro['iris_custom_button_status'];
				if ($paramstbiro['iris_backurl'] != ''){
					if (preg_match("#https?://#", $paramstbiro['iris_backurl']) === 0) {
						$iris_backurl = 'http://'.$paramstbiro['iris_backurl'];
					}else{
						$iris_backurl = $paramstbiro['iris_backurl'];
					}
				}else{
					$iris_backurl = '';
				}
				
				$tbiro_tbi_btn_theme = $paramstbiro['tbi_btn_theme'];
				
				if ($tbiro_iris_custom_button_status == 'Yes') {
					echo '<table border="0" cellpadding="0" cellspacing="0">';
					echo '<tr>';
					echo '<td style="float:left;padding-right:5px;padding-bottom:5px;">';
					if ($iris_backurl == ''){
						echo "<img id=\"btn_tbiro\" style=\"min-width:155px;min-height:55px;\" src=\"".TBIRO_LIVEURL."/calculators/assets/img/custom_buttons_iris/" . $tbiro_unicid . ".png\" title=\"Credit module IRIS Pay " . TBIRO_MOD_VERSION . "\" alt=\"Credit module IRIS Pay " . TBIRO_MOD_VERSION . "\" onmouseover=\"this.src='".TBIRO_LIVEURL."/calculators/assets/img/custom_buttons_iris/" . $tbiro_unicid . "_hover.png'\" onmouseout=\"this.src='".TBIRO_LIVEURL."/calculators/assets/img/custom_buttons_iris/" . $tbiro_unicid . ".png'\">";
					}else{
						echo "<a href=\"" . $iris_backurl . "\" target=\"_blank\" style=\"float:left;\" title=\"Go to IRIS Pay page\"><img id=\"btn_tbiro\" style=\"cursor:pointer;min-width:155px;min-height:55px;\" src=\"".TBIRO_LIVEURL."/calculators/assets/img/custom_buttons_iris/" . $tbiro_unicid . ".png\" title=\"Credit module IRIS Pay " . TBIRO_MOD_VERSION . "\" alt=\"Credit module IRIS Pay " . TBIRO_MOD_VERSION . "\" onmouseover=\"this.src='".TBIRO_LIVEURL."/calculators/assets/img/custom_buttons_iris/" . $tbiro_unicid . "_hover.png'\" onmouseout=\"this.src='".TBIRO_LIVEURL."/calculators/assets/img/custom_buttons_iris/" . $tbiro_unicid . ".png'\"></a>";
					}
					echo '</td>';
					echo '</tr>';
					echo '</table>';					
				}else{
					echo '<table border="0" cellpadding="0" cellspacing="0">';
					echo '<tr>';
					echo '<td style="float:left;padding-right:5px;padding-bottom:5px;">';
					if ($iris_backurl == ''){
						echo "<img id=\"btn_tbiro\" style=\"min-width:155px;min-height:55px;\" src=\"".TBIRO_LIVEURL."/calculators/assets/img/buttons/" . $tbiro_tbi_btn_theme . ".png\" title=\"Credit module tbi bank " . TBIRO_MOD_VERSION . "\" alt=\"Credit module tbi bank " . TBIRO_MOD_VERSION . "\" onmouseover=\"this.src='".TBIRO_LIVEURL."/calculators/assets/img/buttons/" . $tbiro_tbi_btn_theme . "-hover.png'\" onmouseout=\"this.src='".TBIRO_LIVEURL."/calculators/assets/img/buttons/" . $tbiro_tbi_btn_theme . ".png'\">";
					}else{
						echo "<a href=\"" . $iris_backurl . "\" target=\"_blank\" title=\"Go to tbi bank page\"><img id=\"btn_tbiro\" style=\"cursor:pointer;min-width:155px;min-height:55px;\" src=\"".TBIRO_LIVEURL."/calculators/assets/img/buttons/" . $tbiro_tbi_btn_theme . ".png\" title=\"Credit module tbi bank " . TBIRO_MOD_VERSION . "\" alt=\"Credit module tbi bank " . TBIRO_MOD_VERSION . "\" onmouseover=\"this.src='".TBIRO_LIVEURL."/calculators/assets/img/buttons/" . $tbiro_tbi_btn_theme . "-hover.png'\" onmouseout=\"this.src='".TBIRO_LIVEURL."/calculators/assets/img/buttons/" . $tbiro_tbi_btn_theme . ".png'\"></a>";
					}
					echo '</td>';
					echo '</tr>';
					echo '</table>';					
				}				
			}
			
			public function process_payment( $order_id ) {
				$order = wc_get_order( $order_id );
				$status = 'wc-' === substr( $this->order_status, 0, 3 ) ? substr( $this->order_status, 3 ) : $this->order_status;
				// Set order status
				$order->update_status( $status, __( 'IRIS Pay. ', 'tbicreditro' ) );
				
				$tbiro_unicid = (string)get_option("tbiro_unicid");
				$tbiro_store_id = (string)get_option('credittbiro_store_id');
				$tbiro_password = (string)get_option('credittbiro_password');
				$tbiro_iris_iban = (string)get_option('credittbiro_iris_iban');
				$tbiro_iris_user = (string)get_option('credittbiro_iris_user');
				$tbiro_ch = curl_init();
				curl_setopt($tbiro_ch, CURLOPT_SSL_VERIFYPEER, false);
				curl_setopt($tbiro_ch, CURLOPT_RETURNTRANSFER, true);
				curl_setopt($tbiro_ch, CURLOPT_URL, TBIRO_LIVEURL . '/function/getparameters.php?cid='.$tbiro_unicid);
				$paramstbiro = json_decode(curl_exec($tbiro_ch), true);
				curl_close($tbiro_ch);
				
				if (empty($paramstbiro)){
					return NULL;
				}
				
				global $woocommerce;
				$tbiro__price = 0;
				$tbiro__minprice = $paramstbiro['tbi_minstojnost'];
				$tbiro__price = $woocommerce->cart->total;
				
				$tbiro_products = '';
				$tbiro_products_q = '';
				$tbiro_products_n = '';
				$ident = 0;
				$tbiro_api_items = array();
				foreach($woocommerce->cart->get_cart() as $cart_item){
					if(!empty($cart_item)){
						$tbiro_items[$ident]['name'] = $cart_item['data']->get_title();
						$tbiro_api_items[$ident]['name'] = $cart_item['data']->get_title();
						$tbiro_api_items[$ident]['description'] = '';
						$tbiro_quantity = $cart_item['quantity'];
						$tbiro_items[$ident]['qty'] = "$tbiro_quantity";
						$tbiro_api_items[$ident]['qty'] = "$tbiro_quantity";
						$tbiro_price = (float)$cart_item['line_total'] / (float)$cart_item['quantity'];
						$tbiro_items[$ident]['price'] = "$tbiro_price";
						$tbiro_api_items[$ident]['price'] = "$tbiro_price";
						$terms = get_the_terms( $cart_item['product_id'], 'product_cat' );
						foreach ($terms as $term){
							$tbiro_category = $term->term_id;
						}
						$tbiro_items[$ident]['category'] = "$tbiro_category";
						$tbiro_product_id = $cart_item['product_id'];
						$tbiro_items[$ident]['sku'] = "$tbiro_product_id";
						$tbiro_api_items[$ident]['sku'] = "$tbiro_product_id";
						$tbiro_api_items[$ident]['category'] = "$tbiro_category";
						$tbiro_image = wp_get_attachment_image_src( get_post_thumbnail_id( $cart_item['product_id'] ), 'single-post-thumbnail' );
						$tbiro_imagePath = isset($tbiro_image[0]) ? $tbiro_image[0] : '';
						$tbiro_items[$ident]['ImageLink'] = "$tbiro_imagePath";
						$tbiro_api_items[$ident]['ImageLink'] = "$tbiro_imagePath";
						$ident++;
					}
				}
				
				global $current_user;
				get_currentuserinfo();
				
				$tbiro_url = TBIRO_LIVEURL . "/function/status.php";
				$tbiro_fname = isset($current_user->user_firstname) ? $current_user->user_firstname : tbiro_wordpress_get_params( 'billing_first_name', '' );
				$tbiro_lname = isset($current_user->user_firstname) ? $current_user->user_lastname : tbiro_wordpress_get_params( 'billing_last_name', '' );
				$tbiro_cnp = '';
				$tbiro_email = isset($current_user->user_email) ? $current_user->user_email : tbiro_wordpress_get_params( 'billing_email', '' );
				$tbiro_person_type = '';
				$tbiro_net_income = '';
				$tbiro_instalments = '';
				$tbiro_quantity = tbiro_wordpress_get_params( 'tbiro_newq', 1 );
				$tbiro_product_category = '';
				$tbiro_customer = new WC_Customer( $current_user->ID );
				$tbiro_phone = ($tbiro_customer->get_billing_phone() !== '') ? $tbiro_customer->get_billing_phone() : tbiro_wordpress_get_params( 'billing_phone', '' );
				$tbiro_billing_address = ($tbiro_customer->get_billing_address() !== '') ? $tbiro_customer->get_billing_address() : tbiro_wordpress_get_params( 'billing_address_1', '' ) . ' ' . tbiro_wordpress_get_params( 'billing_address_2', '' );
				$tbiro_billing_city = ($tbiro_customer->get_billing_city() !== '') ? $tbiro_customer->get_billing_city() : tbiro_wordpress_get_params( 'billing_city', '' );
				$tbiro_billing_county = ($tbiro_customer->get_billing_state() !== '') ? $tbiro_customer->get_billing_state() : tbiro_wordpress_get_params( 'billing_state', '' );
				$tbiro_shipping_address = ($tbiro_customer->get_shipping_address() !== '') ? $tbiro_customer->get_shipping_address() : tbiro_wordpress_get_params( 'billing_address_1', '' ) . ' ' . tbiro_wordpress_get_params( 'billing_address_2', '' );
				$tbiro_shipping_city = ($tbiro_customer->get_shipping_city() !== '') ? $tbiro_customer->get_shipping_city() : tbiro_wordpress_get_params( 'billing_city', '' );
				$tbiro_shipping_county = ($tbiro_customer->get_shipping_state() !== '') ? $tbiro_customer->get_shipping_state() : tbiro_wordpress_get_params( 'billing_state', '' );
				
				// Create order in cp
				$tbiro_add_ch = curl_init();
				curl_setopt($tbiro_add_ch, CURLOPT_SSL_VERIFYPEER, false);
				curl_setopt($tbiro_add_ch, CURLOPT_RETURNTRANSFER, true);
				curl_setopt($tbiro_add_ch, CURLOPT_URL, TBIRO_LIVEURL . '/function/addorders.php?cid='.$tbiro_unicid);
				curl_setopt($tbiro_add_ch, CURLOPT_POST, 1);
				
				$tbiro_post = array(
					'store_id'      => $tbiro_store_id,
					'order_id'      =>  $order_id,
					'type'      	=>  'IRIS',
					'back_ref'      =>  $tbiro_url,
					'order_total'   =>  $tbiro__price,
					'username'		=> $tbiro_username,
					'password'		=> $tbiro_password,
					'customer'      =>  array(
						'fname'         => $tbiro_fname,
						'lname'         => $tbiro_lname,
						'cnp'           => $tbiro_cnp, 
						'email'         => $tbiro_email,
						'phone'         => $tbiro_phone,
						'billing_address'      => $tbiro_billing_address,
						'billing_city'          => $tbiro_billing_city,
						'billing_county'        => $tbiro_billing_county,
						'shipping_address'      => $tbiro_shipping_address,
						'shipping_city'          => $tbiro_shipping_city,
						'shipping_county'        => $tbiro_shipping_county,
						'person_type'   => $tbiro_person_type,
						'net_income'    => $tbiro_net_income,
						'instalments'	=> $tbiro_instalments
					),
					'items' => $tbiro_items
				);
				
				curl_setopt($tbiro_add_ch, CURLOPT_POSTFIELDS, http_build_query($tbiro_post));
				$paramstbiroadd=json_decode(curl_exec($tbiro_add_ch), true);
				curl_close($tbiro_add_ch);
				
				// Created order in cp
				if (isset($paramstbiroadd['status']) && ($paramstbiroadd['status'] == 'Yes')){
					// save to tbiorders file
					$tbiro_tempcontent = file_get_contents(TBIRO_PLUGIN_DIR . '/keys/tbiroorders.json');
					if ($tbiro_tempcontent != false){
						$tbiro_orders = json_decode($tbiro_tempcontent);
						// test over 1000
						if (is_array($tbiro_orders) && (count($tbiro_orders) >= 1000)){
							array_shift($tbiro_orders);
						}
						$tbiro_order_current = array(
							"order_id" => $order_id,
							"order_status" => "Draft"
						);
						$key = array_search($order_id, array_map(
							function($o) {
								return $o->order_id;
							}, 
							$tbiro_orders));
						if ($key === false){
							array_push($tbiro_orders, $tbiro_order_current);
						}
						$jsondata = json_encode($tbiro_orders);
						file_put_contents(TBIRO_PLUGIN_DIR . '/keys/tbiroorders.json', $jsondata);
					}
					
					// send to IRIS
					$tbiroiris_post = array(
						'currency'      	=> 'RON',
						'description'      	=> 'TBI IRIS Payment',
						'hookUrl'      		=> $tbiro_url . '?order=' . $paramstbiroadd['newid'],
						'name'   			=> '',
						'redirectUrl'		=> wc_get_checkout_url(),
						'sum'				=> $tbiro__price,
						'toIban'         	=> $tbiro_iris_iban,
						'orderId'			=> $paramstbiroadd['newid'] . "," . $order_id
					);
					if ($paramstbiro['iris_testenv'] == 1){
						$tbiroiris_envurl = $paramstbiro['iris_testurl'];
					}else{
						$tbiroiris_envurl = $paramstbiro['iris_liveurl'];
					}
					
					$tbiroiris_plaintext = json_encode($tbiroiris_post);
					$tbiro_iris_key = (string)get_option('credittbiro_iris_key');
					$curl_application = curl_init();
					curl_setopt_array($curl_application, array(
						CURLOPT_URL => $tbiroiris_envurl . '/' . $tbiro_iris_key,
						CURLOPT_RETURNTRANSFER => true,
						CURLOPT_ENCODING => '',
						CURLOPT_MAXREDIRS => 4,
						CURLOPT_TIMEOUT => 0,
						CURLOPT_FOLLOWLOCATION => true,
						CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
						CURLOPT_CUSTOMREQUEST => 'POST',
						CURLOPT_POSTFIELDS => $tbiroiris_plaintext,
						CURLOPT_HTTPHEADER => array(
							'Content-Type: application/json'
						),
					));
					$response_application = curl_exec($curl_application);
					$curl_iris_error = curl_error($curl_application);
					curl_close($curl_application);
					
					if ($curl_iris_error){
						wc_add_notice(__( 'Communication error. You cannot create an order in iris. Please try again later.', 'tbicreditro' ), 'error');
						return NULL;
					}else{
						$tbiroiris_result = json_decode($response_application);
						if ($tbiroiris_result->paymentLink != null){
							$tbiroiris_url = $tbiroiris_result->paymentLink;
							WC()->cart->empty_cart();
							return array(
								'result'    => 'success',
								'redirect'  => esc_url_raw($tbiroiris_url)
							);
						}else{
							wc_add_notice(__( 'You cannot create an order in iris. Please try again later.', 'tbicreditro' ), 'error');
							return NULL;
						}
					}
				}else{
					wc_add_notice(__( 'You cannot create an order in tbi bank cp. Please try again later.', 'tbicreditro' ), 'error');
					return NULL;
				}
			}
			
		}
		
	}
	
	/** payment gateway **/
	function add_tbiro_gateway_class( $methods ) {
		$methods[] = 'WC_Gateway_Tbiro_Gateway'; 
		$methods[] = 'WC_Gateway_Tbiroiris_Gateway';
		return $methods;
	}
	
	/** vizualize credit button */
	function tbiro_credit_button() {
		$credittbiro_status = intval(get_option('credittbiro_status'));
		if ($credittbiro_status === 1){
			global $product;
			$tbiro__price = 0;
			$tbiro_unicid = (string)get_option("tbiro_unicid");
			$tbiro_ch = curl_init();
			curl_setopt($tbiro_ch, CURLOPT_SSL_VERIFYPEER, false);
			curl_setopt($tbiro_ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($tbiro_ch, CURLOPT_URL, TBIRO_LIVEURL . '/function/getparameters.php?cid='.$tbiro_unicid);
			$paramstbiro = json_decode(curl_exec($tbiro_ch), true);
			curl_close($tbiro_ch);
			
			if (empty($paramstbiro)){
				return NULL;
			}
		
			$tbiro__minprice = $paramstbiro['tbi_minstojnost'];
			$tbiro__maxprice = $paramstbiro['tbi_maxstojnost'];
			$tbiro_tbi_btn_theme = $paramstbiro['tbi_btn_theme'];
			$tbiro__price = $product->get_price();
			$tbiro_tbi_custom_button_status = $paramstbiro['tbi_custom_button_status'];
		
			$tbi_btn_color = '#e55a00;';
			if ($paramstbiro['tbi_btn_theme'] == 'tbi'){
				$tbi_btn_color = '#e55a00;';
			}
			if ($paramstbiro['tbi_btn_theme'] == 'tbi2'){
				$tbi_btn_color = '#00368a;';
			}
			if ($paramstbiro['tbi_btn_theme'] == 'tbi3'){
				$tbi_btn_color = '#2b7953;';
			}
			if ($paramstbiro['tbi_btn_theme'] == 'tbi4'){
				$tbi_btn_color = '#848789;';
			}
			
			if ($tbiro__price == 0){
				$tbiro_is_empty = true;
			}else{
				$tbiro_is_empty = false;
			}
		
			if ($paramstbiro['tbi_status'] == 'Yes'){
				$tbiro_is_active = true;
			}else{
				$tbiro_is_active = false;
			}
			
			if ($tbiro__price >= $tbiro__minprice && $tbiro__price <= $tbiro__maxprice){
				$tbiro_is_visible = true;
			}else{
				$tbiro_is_visible = false;
			}
			$tbiro_zaiavka1tbi_text = $paramstbiro['tbi_zaglavie'];
			$tbiro_zaiavka2tbi_text = $paramstbiro['tbi_opisanie'];
			$tbiro_zaiavka3tbi_text = $paramstbiro['tbi_product'];
			$tbiro_vnoska = $paramstbiro['tbi_vnoska'];
			if ($paramstbiro['tbi_backurl'] != ''){
				if (preg_match("#https?://#", $paramstbiro['tbi_backurl']) === 0) {
					$tbiro_backurl = 'http://'.$paramstbiro['tbi_backurl'];
				}else{
					$tbiro_backurl = $paramstbiro['tbi_backurl'];
				}
			}else{
				$tbiro_backurl = '';
			}
		
			$tbi_divider = floatval($paramstbiro['tbi_divider']);
			$tbi_divider2 = floatval($paramstbiro['tbi_divider2']);
			$tbi_divider2_is = boolval($paramstbiro['tbi_divider2_is']);
			$tbi_divider3 = floatval($paramstbiro['tbi_divider3']);
			$tbi_divider3_is = boolval($paramstbiro['tbi_divider3_is']);
			$tbi_divider4 = floatval($paramstbiro['tbi_divider4']);
			$tbi_divider4_is = boolval($paramstbiro['tbi_divider4_is']);
			$tbi_divider5 = floatval($paramstbiro['tbi_divider5']);
			$tbi_divider5_is = boolval($paramstbiro['tbi_divider5_is']);
			
			if ($tbi_divider5_is){
				//divider 5
				if ($tbiro__price < $tbi_divider){
					$tbi_rate = floatval($paramstbiro['tbi_rate']);
					$tbi_commission = floatval($paramstbiro['tbi_commission']);
					$tbi_insurance = floatval($paramstbiro['tbi_insurance']);
					$tbi_months = intval($paramstbiro['tbi_months']);
				}else{
					if ($tbiro__price >= $tbi_divider && $tbiro__price < $tbi_divider2){
						$tbi_rate = floatval($paramstbiro['tbi_rate2']);
						$tbi_commission = floatval($paramstbiro['tbi_commission2']);
						$tbi_insurance = floatval($paramstbiro['tbi_insurance2']);
						$tbi_months = intval($paramstbiro['tbi_months2']);
					}else{
						if ($tbiro__price >= $tbi_divider2 && $tbiro__price < $tbi_divider3){
							$tbi_rate = floatval($paramstbiro['tbi_rate3']);
							$tbi_commission = floatval($paramstbiro['tbi_commission3']);
							$tbi_insurance = floatval($paramstbiro['tbi_insurance3']);
							$tbi_months = intval($paramstbiro['tbi_months3']);
						}else{
							if ($tbiro__price >= $tbi_divider3 && $tbiro__price < $tbi_divider4){
								$tbi_rate = floatval($paramstbiro['tbi_rate4']);
								$tbi_commission = floatval($paramstbiro['tbi_commission4']);
								$tbi_insurance = floatval($paramstbiro['tbi_insurance4']);
								$tbi_months = intval($paramstbiro['tbi_months4']);
							}else{
								if ($tbiro__price >= $tbi_divider4 && $tbiro__price < $tbi_divider5){
									$tbi_rate = floatval($paramstbiro['tbi_rate5']);
									$tbi_commission = floatval($paramstbiro['tbi_commission5']);
									$tbi_insurance = floatval($paramstbiro['tbi_insurance5']);
									$tbi_months = intval($paramstbiro['tbi_months5']);
								}else{
									$tbi_rate = floatval($paramstbiro['tbi_rate6']);
									$tbi_commission = floatval($paramstbiro['tbi_commission6']);
									$tbi_insurance = floatval($paramstbiro['tbi_insurance6']);
									$tbi_months = intval($paramstbiro['tbi_months6']);
								}
							}
						}
					}
				}
			}else{
				if ($tbi_divider4_is){
					//divider 4
					if ($tbiro__price < $tbi_divider){
						$tbi_rate = floatval($paramstbiro['tbi_rate']);
						$tbi_commission = floatval($paramstbiro['tbi_commission']);
						$tbi_insurance = floatval($paramstbiro['tbi_insurance']);
						$tbi_months = intval($paramstbiro['tbi_months']);
					}else{
						if ($tbiro__price >= $tbi_divider && $tbiro__price < $tbi_divider2){
							$tbi_rate = floatval($paramstbiro['tbi_rate2']);
							$tbi_commission = floatval($paramstbiro['tbi_commission2']);
							$tbi_insurance = floatval($paramstbiro['tbi_insurance2']);
							$tbi_months = intval($paramstbiro['tbi_months2']);
						}else{
							if ($tbiro__price >= $tbi_divider2 && $tbiro__price < $tbi_divider3){
								$tbi_rate = floatval($paramstbiro['tbi_rate3']);
								$tbi_commission = floatval($paramstbiro['tbi_commission3']);
								$tbi_insurance = floatval($paramstbiro['tbi_insurance3']);
								$tbi_months = intval($paramstbiro['tbi_months3']);
							}else{
								if ($tbiro__price >= $tbi_divider3 && $tbiro__price < $tbi_divider4){
									$tbi_rate = floatval($paramstbiro['tbi_rate4']);
									$tbi_commission = floatval($paramstbiro['tbi_commission4']);
									$tbi_insurance = floatval($paramstbiro['tbi_insurance4']);
									$tbi_months = intval($paramstbiro['tbi_months4']);
								}else{
									$tbi_rate = floatval($paramstbiro['tbi_rate5']);
									$tbi_commission = floatval($paramstbiro['tbi_commission5']);
									$tbi_insurance = floatval($paramstbiro['tbi_insurance5']);
									$tbi_months = intval($paramstbiro['tbi_months5']);
								}
							}
						}
					}
				}else{
					if ($tbi_divider3_is){
						//divider 3
						if ($tbiro__price < $tbi_divider){
							$tbi_rate = floatval($paramstbiro['tbi_rate']);
							$tbi_commission = floatval($paramstbiro['tbi_commission']);
							$tbi_insurance = floatval($paramstbiro['tbi_insurance']);
							$tbi_months = intval($paramstbiro['tbi_months']);
						}else{
							if ($tbiro__price >= $tbi_divider && $tbiro__price < $tbi_divider2){
								$tbi_rate = floatval($paramstbiro['tbi_rate2']);
								$tbi_commission = floatval($paramstbiro['tbi_commission2']);
								$tbi_insurance = floatval($paramstbiro['tbi_insurance2']);
								$tbi_months = intval($paramstbiro['tbi_months2']);
							}else{
								if ($tbiro__price >= $tbi_divider2 && $tbiro__price < $tbi_divider3){
									$tbi_rate = floatval($paramstbiro['tbi_rate3']);
									$tbi_commission = floatval($paramstbiro['tbi_commission3']);
									$tbi_insurance = floatval($paramstbiro['tbi_insurance3']);
									$tbi_months = intval($paramstbiro['tbi_months3']);
								}else{
									$tbi_rate = floatval($paramstbiro['tbi_rate4']);
									$tbi_commission = floatval($paramstbiro['tbi_commission4']);
									$tbi_insurance = floatval($paramstbiro['tbi_insurance4']);
									$tbi_months = intval($paramstbiro['tbi_months4']);
								}
							}
						}
					}else{
						if ($tbi_divider2_is){
							//divider 2
							if ($tbiro__price < $tbi_divider){
								$tbi_rate = floatval($paramstbiro['tbi_rate']);
								$tbi_commission = floatval($paramstbiro['tbi_commission']);
								$tbi_insurance = floatval($paramstbiro['tbi_insurance']);
								$tbi_months = intval($paramstbiro['tbi_months']);
							}else{
								if ($tbiro__price >= $tbi_divider && $tbiro__price < $tbi_divider2){
									$tbi_rate = floatval($paramstbiro['tbi_rate2']);
									$tbi_commission = floatval($paramstbiro['tbi_commission2']);
									$tbi_insurance = floatval($paramstbiro['tbi_insurance2']);
									$tbi_months = intval($paramstbiro['tbi_months2']);
								}else{
									$tbi_rate = floatval($paramstbiro['tbi_rate3']);
									$tbi_commission = floatval($paramstbiro['tbi_commission3']);
									$tbi_insurance = floatval($paramstbiro['tbi_insurance3']);
									$tbi_months = intval($paramstbiro['tbi_months3']);
								}
							}
						}else{
							//no dividers
							if ($tbiro__price < $tbi_divider){
								$tbi_rate = floatval($paramstbiro['tbi_rate']);
								$tbi_commission = floatval($paramstbiro['tbi_commission']);
								$tbi_insurance = floatval($paramstbiro['tbi_insurance']);
								$tbi_months = intval($paramstbiro['tbi_months']);
							}else{
								$tbi_rate = floatval($paramstbiro['tbi_rate2']);
								$tbi_commission = floatval($paramstbiro['tbi_commission2']);
								$tbi_insurance = floatval($paramstbiro['tbi_insurance2']);
								$tbi_months = intval($paramstbiro['tbi_months2']);
							}
						}
					}
				}
			}
			
			if ($tbi_rate == 0){
				$tbi_rate = 1;
			}
		
			$tbiro_mesecna = tbiro_PMT(($tbi_rate / 100) / 12, $tbi_months,  - ($tbiro__price + $tbi_commission) * (1 + $tbi_insurance * $tbi_months));
			
			$tbiro_btnvisible = $paramstbiro['tbi_btnvisible'];
			
			if ($tbiro_btnvisible == 'Yes'){
				if (!$tbiro_is_empty) {
					if ($tbiro_is_active) {
						if (($tbiro_zaiavka1tbi_text != '') || ($tbiro_zaiavka2tbi_text != '') || ($tbiro_zaiavka3tbi_text != '')) {
							echo "<br /><span style=\"font-size:22px;font-weight:bold;\">$tbiro_zaiavka1tbi_text</span> <span style=\"font-size:18px;\">$tbiro_zaiavka2tbi_text</span> $tbiro_zaiavka3tbi_text";
						}
						if ($tbiro_is_visible) {
							if ($tbiro_tbi_custom_button_status == 'Yes') {
								if ($tbiro_vnoska == 'Yes'){
									echo '<table border="0" style="max-width:400px;">';
									echo '<tr>';
									echo '<td style="padding-right:5px;padding-bottom:5px;">';
									if ($tbiro_backurl == ''){
										echo "<img id=\"btn_tbiro\" style=\"padding-bottom: 5px;\" src=\"".TBIRO_LIVEURL."/calculators/assets/img/custom_buttons/" . $tbiro_unicid . ".png\" title=\"Credit module tbi bank " . TBIRO_MOD_VERSION . "\" alt=\"Credit module tbi bank " . TBIRO_MOD_VERSION . "\" onmouseover=\"this.src='".TBIRO_LIVEURL."/calculators/assets/img/custom_buttons/" . $tbiro_unicid . "_hover.png'\" onmouseout=\"this.src='".TBIRO_LIVEURL."/calculators/assets/img/custom_buttons/" . $tbiro_unicid . ".png'\">";
									}else{
										echo "<a href=\"" . $tbiro_backurl . "\" target=\"_blank\" title=\"Go to tbi bank page\"><img id=\"btn_tbiro\" style=\"padding-bottom: 5px;cursor:pointer;\" src=\"".TBIRO_LIVEURL."/calculators/assets/img/custom_buttons/" . $tbiro_unicid . ".png\" title=\"Credit module tbi bank " . TBIRO_MOD_VERSION . "\" alt=\"Credit module tbi bank " . TBIRO_MOD_VERSION . "\" onmouseover=\"this.src='".TBIRO_LIVEURL."/calculators/assets/img/custom_buttons/" . $tbiro_unicid . "_hover.png'\" onmouseout=\"this.src='".TBIRO_LIVEURL."/calculators/assets/img/custom_buttons/" . $tbiro_unicid . ".png'\"></a>";
									}
									echo '</td>';
									echo '</tr>';
									echo '<tr>';
									echo '<td style="vertical-align:bottom;">';
									echo '<p style="color:' . $tbi_btn_color . 'font-size:16pt;font-weight:bold;">' . number_format($tbiro_mesecna, 2, '.', '') . ' ' . __('EUR', 'tbicreditro') . ' x ' . $tbi_months . ' ' . __('months', 'tbicreditro') . '</p>';
									echo '</td>';
									echo '</tr>';
									echo '</table>';
								}else{
									echo "<a href=\"" . $tbiro_backurl . "\" target=\"_blank\" title=\"Go to tbi bank page\"><img id=\"btn_tbiro\" style=\"padding-bottom: 5px;cursor:pointer;\" src=\"".TBIRO_LIVEURL."/calculators/assets/img/custom_buttons/" . $tbiro_unicid . ".png\" title=\"Credit module tbi bank " . TBIRO_MOD_VERSION . "\" alt=\"Credit module tbi bank " . TBIRO_MOD_VERSION . "\" onmouseover=\"this.src='".TBIRO_LIVEURL."/calculators/assets/img/custom_buttons/" . $tbiro_unicid . "_hover.png'\" onmouseout=\"this.src='".TBIRO_LIVEURL."/calculators/assets/img/custom_buttons/" . $tbiro_unicid . ".png'\"></a>";
								}
							}else{
								if ($tbiro_vnoska == 'Yes'){
									echo '<table border="0" style="max-width:400px;">';
									echo '<tr>';
									echo '<td style="padding-right:5px;padding-bottom:5px;">';
									if ($tbiro_backurl == ''){
										echo "<img id=\"btn_tbiro\" style=\"padding-bottom: 5px;\" src=\"".TBIRO_LIVEURL."/calculators/assets/img/buttons/" . $tbiro_tbi_btn_theme . ".png\" title=\"Credit module tbi bank " . TBIRO_MOD_VERSION . "\" alt=\"Credit module tbi bank " . TBIRO_MOD_VERSION . "\" onmouseover=\"this.src='".TBIRO_LIVEURL."/calculators/assets/img/buttons/" . $tbiro_tbi_btn_theme . "-hover.png'\" onmouseout=\"this.src='".TBIRO_LIVEURL."/calculators/assets/img/buttons/" . $tbiro_tbi_btn_theme . ".png'\">";
									}else{
										echo "<a href=\"" . $tbiro_backurl . "\" target=\"_blank\" title=\"Go to tbi bank page\"><img id=\"btn_tbiro\" style=\"padding-bottom: 5px;cursor:pointer;\" src=\"".TBIRO_LIVEURL."/calculators/assets/img/buttons/" . $tbiro_tbi_btn_theme . ".png\" title=\"Credit module tbi bank " . TBIRO_MOD_VERSION . "\" alt=\"Credit module tbi bank " . TBIRO_MOD_VERSION . "\" onmouseover=\"this.src='".TBIRO_LIVEURL."/calculators/assets/img/buttons/" . $tbiro_tbi_btn_theme . "-hover.png'\" onmouseout=\"this.src='".TBIRO_LIVEURL."/calculators/assets/img/buttons/" . $tbiro_tbi_btn_theme . ".png'\"></a>";
									}
									echo '</td>';
									echo '</tr>';
									echo '<tr>';
									echo '<td style="vertical-align:bottom;">';
									echo '<p style="color:' . $tbi_btn_color . 'font-size:16pt;font-weight:bold;">' . number_format($tbiro_mesecna, 2, '.', '') . ' ' . __('EUR', 'tbicreditro') . ' x ' . $tbi_months . ' ' . __('months', 'tbicreditro') . '</p>';
									echo '</td>';
									echo '</tr>';
									echo '</table>';
								}else{
									echo "<a href=\"" . $tbiro_backurl . "\" target=\"_blank\" title=\"Go to tbi bank page\"><img id=\"btn_tbiro\" style=\"padding-bottom: 5px;cursor:pointer;\" src=\"".TBIRO_LIVEURL."/calculators/assets/img/buttons/" . $tbiro_tbi_btn_theme . ".png\" title=\"Credit module tbi bank " . TBIRO_MOD_VERSION . "\" alt=\"Credit module tbi bank " . TBIRO_MOD_VERSION . "\" onmouseover=\"this.src='".TBIRO_LIVEURL."/calculators/assets/img/buttons/" . $tbiro_tbi_btn_theme . "-hover.png'\" onmouseout=\"this.src='".TBIRO_LIVEURL."/calculators/assets/img/buttons/" . $tbiro_tbi_btn_theme . ".png'\"></a>";
								}
							}
						}
					}
				}
			}
		}
	}
	
	function tbiro_add_query_vars_filter( $vars ){
		$vars[] = "product";
		$vars[] = "products_price";
		$vars[] = "vnoski";
		$vars[] = "redoven";
		return $vars;
	}
	
	function tbiro_wordpress_get_params($param = null,$null_return = null){
		if ($param){
			$value = (!empty($_POST[$param]) ? trim(esc_sql($_POST[$param])) : (!empty($_GET[$param]) ? trim(esc_sql($_GET[$param])) : $null_return ));
			return $value;
			} else {
			$params = array();
			foreach ($_POST as $key => $param) {
				$params[trim(esc_sql($key))] = (!empty($_POST[$key]) ? trim(esc_sql($_POST[$key])) :  $null_return );
			}
			foreach ($_GET as $key => $param) {
				$key = trim(esc_sql($key));
				if (!isset($params[$key])) { // if there is no key or it's a null value
					$params[trim(esc_sql($key))] = (!empty($_GET[$key]) ? trim(esc_sql($_GET[$key])) : $null_return );
				}
			}
			return $params;
		}
	}	
	
	function tbiro_add_meta() {
		//register css-s
		wp_enqueue_style( 'tbiro_style', plugin_dir_url( __FILE__ ) . '../css/tbi_style.css', array(), TBIRO_MOD_VERSION, 'all');
		wp_enqueue_script( 'tbiro_credit', plugin_dir_url( __FILE__ ) . '../js/tbicredit.js', false, TBIRO_MOD_VERSION);
	}
	
	function tbiro_reklama() {
		$o = '';
		if ( is_front_page() ) {	
			$tbiro_unicid = (string)get_option("tbiro_unicid");
			$tbiro_ch = curl_init();
			curl_setopt($tbiro_ch, CURLOPT_SSL_VERIFYPEER, false);
			curl_setopt($tbiro_ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($tbiro_ch, CURLOPT_URL, TBIRO_LIVEURL . '/function/getparameters.php?cid='.$tbiro_unicid);
			$paramstbiro=json_decode(curl_exec($tbiro_ch), true);
			curl_close($tbiro_ch);
			
			if (empty($paramstbiro)){
				return NULL;
			}
				
			if (($paramstbiro['tbi_container_status'] == 'Yes') && ($paramstbiro['tbi_status'] == 'Yes')){ 
				$o .= '<div class="tbiro_float" onclick="tbiroChangeContainer();">';
				$o .= '<img src="'.TBIRO_LIVEURL.'/dist/img/tbi_logo.png" class="tbiro-my-float">';
				$o .= '</div>';
				$o .= '<div class="tbiro-label-container">';
				$o .= '<i class="fa fa-play fa-rotate-180 tbiro-label-arrow"></i>';
				$o .= '<div class="tbiro-label-text">';
				$o .= '<div style="padding-bottom:5px;"></div>';
				$o .= '<img src="'.TBIRO_LIVEURL.'/calculators/assets/img/tbim' . $paramstbiro['tbi_container_reklama'] . '.png">';
				$o .= '<div style="font-size:16px;padding-top:3px;">' . $paramstbiro['tbi_container_txt1'] . '</div>';
				$o .= '<p style="font-size:14px;">' . $paramstbiro['tbi_container_txt2'] . '</p>';
				$o .= '<div class="tbi-label-text-a"><a href="'.TBIRO_LIVEURL.'/calculators/assets/img/Procedura%20Online%20TBI%20Bank-2017.pdf" target="_blank" alt="CREDIT ONLINE INFORMATION WITH TBI BANK">CREDIT ONLINE INFORMATION WITH TBI BANK!</a></div>';
				$o .= '</div>';
				$o .= '</div>';
			}
		}
		echo $o;
	} 
	
	add_action( 'wp_ajax_tbiro_updateorder', 'tbiro_updateorder' );
	add_action( 'wp_ajax_nopriv_tbiro_updateorder', 'tbiro_updateorder' );
	
	function tbiro_updateorder() {
		$json = array();
		$json['success'] = 'unsuccess';
		
		$tbiro_unicid = (string)get_option("tbiro_unicid");
		
		if (isset($_REQUEST['order_id'])) {
			$tbiro_order_id = $_REQUEST['order_id'];
		} else {
			$tbiro_order_id = '';
		}
		
		if (isset($_REQUEST['status'])) {
			$tbiro_status = $_REQUEST['status'];
		} else {
			$tbiro_status = '';
		}
		
		if (isset($_REQUEST['calculator_id'])) {
			$tbiro_calculator_id = $_REQUEST['calculator_id'];
		} else {
			$tbiro_calculator_id = '';
		}
		
		if (($tbiro_calculator_id != '') && ($tbiro_unicid == $tbiro_calculator_id)){
			if (file_exists(TBIRO_PLUGIN_DIR . '/keys/tbiroorders.json')) {
				$orderdata = file_get_contents(TBIRO_PLUGIN_DIR . '/keys/tbiroorders.json');
				$tbiro_orderdata_all = json_decode($orderdata, true);
				foreach ($tbiro_orderdata_all as $key => $value){
					if ($tbiro_orderdata_all[$key]['order_id'] == $tbiro_order_id){
						$tbiro_orderdata_all[$key]['order_status'] = $tbiro_status;
					}
				}
				$jsondata = json_encode($tbiro_orderdata_all);
				file_put_contents(TBIRO_PLUGIN_DIR . '/keys/tbiroorders.json', $jsondata);
				$json['success'] = 'success';
			}
		}
		
		$json['tbiro_order_id'] = $tbiro_order_id;
		$json['tbiro_status'] = $tbiro_status;
		$json['tbiro_calculator_id'] = $tbiro_calculator_id;
		
		echo (json_encode($json));
		die();
	}
	
	function headersToArray($str) {
		$headers = array();
		$headersTmpArray = explode( "\r\n" , $str );
		for ( $i = 0 ; $i < count( $headersTmpArray ) ; ++$i )
		{
			if ( strlen( $headersTmpArray[$i] ) > 0 )
			{
				if ( strpos( $headersTmpArray[$i] , ":" ) )
				{
					$headerName = substr( $headersTmpArray[$i] , 0 , strpos( $headersTmpArray[$i] , ":" ) );
					$headerValue = substr( $headersTmpArray[$i] , strpos( $headersTmpArray[$i] , ":" )+1 );
					$headers[$headerName] = $headerValue;
				}
			}
		}
		return $headers;
	}