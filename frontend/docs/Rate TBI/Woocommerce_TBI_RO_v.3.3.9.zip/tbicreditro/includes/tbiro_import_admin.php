<?php 
    if(array_key_exists('tbiro_hidden', $_POST) && $_POST['tbiro_hidden'] == 'Y') {
		if (array_key_exists('credittbiro_status', $_POST)){
			$credittbiro_status = $_POST['credittbiro_status'];
		}else{
			$credittbiro_status = '1';			
		}
        if (array_key_exists('tbiro_unicid', $_POST)){
			$tbiro_unicid = $_POST['tbiro_unicid'];
		}else{
			$tbiro_unicid = '';			
		}
        if (array_key_exists('credittbiro_store_id', $_POST)){
			$credittbiro_store_id = $_POST['credittbiro_store_id'];
		}else{
			$credittbiro_store_id = '';			
		}
        if (array_key_exists('credittbiro_username', $_POST)){
			$credittbiro_username = $_POST['credittbiro_username'];
		}else{
			$credittbiro_username = '';			
		}
        if (array_key_exists('credittbiro_password', $_POST)){
			$credittbiro_password = $_POST['credittbiro_password'];
		}else{
			$credittbiro_password = '';			
		}
        if (array_key_exists('credittbiro_iris_iban', $_POST)){
			$credittbiro_iris_iban = $_POST['credittbiro_iris_iban'];
		}else{
			$credittbiro_iris_iban = '';			
		}
        if (array_key_exists('credittbiro_iris_key', $_POST)){
			$credittbiro_iris_key = $_POST['credittbiro_iris_key'];
		}else{
			$credittbiro_iris_key = '';			
		}
		update_option('credittbiro_status', $credittbiro_status);
		update_option('tbiro_unicid', $tbiro_unicid);
		update_option('credittbiro_store_id', $credittbiro_store_id);
		update_option('credittbiro_username', $credittbiro_username);
		update_option('credittbiro_password', $credittbiro_password);
		update_option('credittbiro_iris_iban', $credittbiro_iris_iban);
		update_option('credittbiro_iris_key', $credittbiro_iris_key);
        ?>
        <div class="updated"><p><strong><?php _e('Settings saved successfully.', 'tbicreditro'); ?></strong></p></div>
        <?php
    } else {
		$credittbiro_status = get_option('credittbiro_status') === '' ? '1' : get_option('credittbiro_status');
        $tbiro_unicid = get_option('tbiro_unicid');
        $credittbiro_store_id = get_option('credittbiro_store_id');
        $credittbiro_username = get_option('credittbiro_username');
        $credittbiro_password = get_option('credittbiro_password');
		$credittbiro_iris_iban = get_option('credittbiro_iris_iban');
        $credittbiro_iris_key = get_option('credittbiro_iris_key');
    }
?>
<div class="wrap">
    <?php    echo "<h2>" . __('tbi bank - all the module settings', 'tbicreditro') . "</h2>"; ?>
    <form name="tbiro_form" method="post" enctype="multipart/form-data" action="<?php echo str_replace( '%7E', '~', $_SERVER['REQUEST_URI']); ?>">
        <input type="hidden" name="tbiro_hidden" value="Y">
        
        <?php echo "<h4>" . __("System settings", "tbicreditro") . "</h4>"; ?>
        <table cellspacing="4" cellpadding="4" border="0" width="900px">
			<tr>
				<td width="300px" style="vertical-align:top;">
					<?php _e('Show button', 'tbicreditro'); ?>
				</td>
				<td width="600px;" style="vertical-align:top;">
					<select name="credittbiro_status" class="mt-currency-form-control" style="width:300px;">
						<option value="1" <?php if ($credittbiro_status == 1){echo "selected";} ?>><?php _e('Enabled', 'tbicreditro'); ?></option>
						<option value="0" <?php if ($credittbiro_status == 0){echo "selected";} ?>><?php _e('Disabled', 'tbicreditro'); ?></option>
					</select><br />
					<span style="font-size:80%;"><?php _e('Show module button on product page.', 'tbicreditro'); ?></span>
				</td>
			</tr>
			<tr>
				<td width="300px" style="vertical-align:top;">
					<?php _e('Unique shop identifier', 'tbicreditro'); ?>
				</td>
				<td width="600px;" style="vertical-align:top;">
					<input type="text" name="tbiro_unicid" value="<?php echo $tbiro_unicid; ?>" size="36" style="width:300px;"><br />
					<span style="font-size:80%;"><?php _e('Unique shop identifier in the tbi bank system.', 'tbicreditro'); ?></span>
				</td>
			</tr>
			<tr>
				<td width="300px" style="vertical-align:top;">
					<?php _e('Store ID for eCommerce tbi bank system', 'tbicreditro'); ?>
				</td>
				<td width="600px;" style="vertical-align:top;">
					<input type="text" name="credittbiro_store_id" value="<?php echo $credittbiro_store_id; ?>" size="36" style="width:300px;"><br />
					<span style="font-size:80%;"><?php _e('Store ID for eCommerce tbi bank system. Required for system authentication.', 'tbicreditro'); ?></span>
				</td>
			</tr>
			<tr>
				<td width="300px" style="vertical-align:top;">
					<?php _e('Username for eCommerce tbi bank system', 'tbicreditro'); ?>
				</td>
				<td width="600px;" style="vertical-align:top;">
					<input type="text" name="credittbiro_username" value="<?php echo $credittbiro_username; ?>" size="36" style="width:300px;"><br />
					<span style="font-size:80%;"><?php _e('Username for eCommerce tbi bank system. Required for system authentication.', 'tbicreditro'); ?></span>
				</td>
			</tr>
			<tr>
				<td width="300px" style="vertical-align:top;">
					<?php _e('Password for eCommerce tbi bank system', 'tbicreditro'); ?>
				</td>
				<td width="600px;" style="vertical-align:top;">
					<input type="text" name="credittbiro_password" value="<?php echo $credittbiro_password; ?>" size="36" style="width:300px;"><br />
					<span style="font-size:80%;"><?php _e('Password for eCommerce tbi bank system. Required for system authentication.', 'tbicreditro'); ?></span>
				</td>
			</tr>
			<tr>
				<td width="300px" style="vertical-align:top;">
					<?php _e('IRIS IBAN', 'tbicreditro'); ?>
				</td>
				<td width="600px;" style="vertical-align:top;">
					<input type="text" name="credittbiro_iris_iban" value="<?php echo $credittbiro_iris_iban; ?>" size="36" style="width:300px;"><br />
					<span style="font-size:80%;"><?php _e('IRIS IBAN.', 'tbicreditro'); ?></span>
				</td>
			</tr>
			<tr>
				<td width="300px" style="vertical-align:top;">
					<?php _e('IRIS Key', 'tbicreditro'); ?>
				</td>
				<td width="600px;" style="vertical-align:top;">
					<input type="text" name="credittbiro_iris_key" value="<?php echo $credittbiro_iris_key; ?>" size="36" style="width:300px;"><br />
					<span style="font-size:80%;"><?php _e('IRIS Key.', 'tbicreditro'); ?></span>
				</td>
			</tr>
        </table>
        <hr />
        <p class="submit">
        <input type="submit" name="Submit" value="<?php echo 'Save changes'; ?>" />
        </p>
    </form>
</div>