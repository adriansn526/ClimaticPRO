<?php
// If uninstall not called from WordPress, then exit.
if (! defined('WP_UNINSTALL_PLUGIN')) {
    exit();
}
global $wpdb;
// remove plugin options
$options = array(
    'credittbiro_status',
	'tbiro_unicid',
	'credittbiro_store_id',
	'credittbiro_username',
	'credittbiro_password',
	'credittbiro_iris_iban',
	'credittbiro_iris_key',
	'woocommerce_tbiirisro_settings',
	'woocommerce_tbiro_settings'
);
foreach ($options as $option) {
	delete_option( $option );
	delete_site_option( $option );
}
// Clear any cached data that has been removed.
wp_cache_flush();