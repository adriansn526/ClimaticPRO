<?php
/**
 * Plugin Name: tbi bank RO
 * Plugin URI: 
 * Description: Credit calculator 
 * Version: 3.4.0
 * Author: Ilko Ivanov
 * Author URI: https://avalonbg.com
 * Text Domain: tbicreditro
 * Domain Path: /languages
 * Network: 
 * License: 
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
if (!defined('TBIRO_LIVEURL'))
define('TBIRO_LIVEURL', 'https://tbicp.com');
/**
 * Check if WooCommerce is active
 **/
if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
    /** definitions */
    define( 'TBIRO_PLUGIN_DIR', untrailingslashit( dirname( __FILE__ ) ) );
    define( 'TBIRO_INCLUDES_DIR', TBIRO_PLUGIN_DIR . '/includes' );
	
	define( 'TBIRO_MOD_VERSION', '3.4.0' );
    /** includes */
    require_once TBIRO_INCLUDES_DIR . '/functions.php';
    require_once TBIRO_INCLUDES_DIR . '/admin.php';
	
	/** add text domain */
	add_action( 'init', 'tbiro_load_textdomain' );
	
	/** add origins */
	add_filter( 'allowed_http_origins', 'tbiro_add_allowed_origins' );
	
	/** add order column tbiro status */
	add_filter( 'manage_edit-shop_order_columns', 'tbiro_add_order_column_status' );
	/** add order column tbiro status values */
	add_action( 'manage_shop_order_posts_custom_column', 'tbiro_add_order_column_status_values', 2 );
	
	//make theme ready for translation
	load_plugin_textdomain( 'tbicreditro', false, TBIRO_PLUGIN_DIR . '/languages' );
    /** add admin menu ###includes/admin.php### */
    add_action('admin_menu', 'tbiro_admin_actions');
    /** output buffer ###includes/functions.php### */
    add_action('init', 'tbiro_do_output_buffer');
    /** vizualize credit button ###includes/functions.php### */
    add_action('woocommerce_after_add_to_cart_button','tbiro_credit_button');
    
    /** reklama ###includes/functions.php### */
	add_action('wp_enqueue_scripts', 'tbiro_add_meta');
    add_action( 'loop_start', 'tbiro_reklama' );
	
	/** payment gateway **/
	add_action( 'plugins_loaded', 'tbiro_init_tbiro_gateway_class' );
	add_action( 'plugins_loaded', 'tbiro_init_tbiiris_gateway_class' );
	add_filter( 'woocommerce_payment_gateways', 'add_tbiro_gateway_class' );
	
	/** check query ###includes/functions.php### */
    add_filter( 'query_vars', 'tbiro_add_query_vars_filter' );	
}